import { TrendingUp, TrendingDown, AlertTriangle, Calendar, Droplets } from 'lucide-react';

interface StatsCardsProps {
  data: {
    totalDays: number;
    totalTrips: number;
    totalActualVolume: number;
    totalPermittedVolume: number;
    avgTripsPerDay: number;
    highTripDays: number;
    peakSeason: string;
    complianceRate: number;
  };
  highlightThreshold: number;
}

export function StatsCards({ data, highlightThreshold }: StatsCardsProps) {
  const {
    totalDays,
    totalTrips,
    totalActualVolume,
    totalPermittedVolume,
    avgTripsPerDay,
    highTripDays,
    peakSeason,
    complianceRate
  } = data;

  const cards = [
    {
      title: 'Total Extraction Days',
      value: totalDays.toString(),
      icon: Calendar,
      color: 'bg-blue-600',
      description: 'Active extraction period'
    },
    {
      title: 'Total Trips',
      value: totalTrips.toLocaleString(),
      icon: TrendingUp,
      color: 'bg-emerald-600',
      description: `${avgTripsPerDay.toFixed(1)} trips/day average`
    },
    {
      title: 'Total Volume',
      value: `${(totalActualVolume / 1000000).toFixed(1)}M kL`,
      icon: Droplets,
      color: 'bg-cyan-600',
      description: 'Actual water extracted'
    },
    {
      title: 'High Activity Days',
      value: highTripDays.toString(),
      icon: AlertTriangle,
      color: highTripDays > 0 ? 'bg-amber-600' : 'bg-gray-600',
      description: `${highlightThreshold}+ trips per day`
    },
    {
      title: 'Peak Season',
      value: peakSeason,
      icon: TrendingUp,
      color: 'bg-purple-600',
      description: 'Highest extraction season'
    },
    {
      title: 'Usage vs Limit',
      value: `${((totalActualVolume / totalPermittedVolume) * 100).toFixed(1)}%`,
      icon: complianceRate > 100 ? TrendingUp : TrendingDown,
      color: complianceRate > 100 ? 'bg-red-600' : 'bg-green-600',
      description: complianceRate > 100 ? 'Over permitted volume' : 'Within limits'
    }
  ];

  return (
    <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
      {cards.map((card, index) => {
        const IconComponent = card.icon;

        return (
          <div key={index} className="bg-gray-800 p-6 rounded-lg shadow-lg border border-gray-700 hover:border-gray-600 transition-colors duration-200">
            <div className="flex items-center justify-between">
              <div className="flex-1">
                <p className="text-sm text-gray-400 font-medium uppercase tracking-wide">
                  {card.title}
                </p>
                <p className="text-2xl font-bold text-white mt-2">
                  {card.value}
                </p>
                <p className="text-sm text-gray-500 mt-1">
                  {card.description}
                </p>
              </div>

              <div className={`${card.color} p-3 rounded-full`}>
                <IconComponent className="w-6 h-6 text-white" />
              </div>
            </div>

            {/* Progress bar for usage percentage */}
            {card.title === 'Usage vs Limit' && (
              <div className="mt-4">
                <div className="w-full bg-gray-700 rounded-full h-2">
                  <div
                    className={`h-2 rounded-full transition-all duration-300 ${
                      complianceRate > 100 ? 'bg-red-500' : 'bg-green-500'
                    }`}
                    style={{
                      width: `${Math.min((totalActualVolume / totalPermittedVolume) * 100, 100)}%`
                    }}
                  />
                </div>
              </div>
            )}
          </div>
        );
      })}
    </div>
  );
}

export default StatsCards;