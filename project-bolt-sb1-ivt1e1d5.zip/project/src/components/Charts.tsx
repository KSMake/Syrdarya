import {
  LineChart,
  Line,
  XAxis,
  YAxis,
  CartesianGrid,
  Tooltip,
  Legend,
  ResponsiveContainer,
  BarChart,
  Bar,
  Area,
  AreaChart
} from 'recharts';
import { AlertTriangle } from 'lucide-react';
import { WaterExtractionData } from '../utils/dataProcessing';

interface ChartProps {
  data: WaterExtractionData[] | any[];
  className?: string;
}

const chartTheme = {
  grid: '#374151',
  text: '#9CA3AF',
  primary: '#3B82F6',
  secondary: '#10B981',
  accent: '#F59E0B',
  warning: '#EF4444'
};

export function ActualVolumeChart({ data, className = '' }: ChartProps) {
  const formatDate = (dateStr: string) => {
    return new Date(dateStr).toLocaleDateString('en-AU', {
      month: 'short',
      day: 'numeric'
    });
  };

  return (
    <div className={`bg-gray-800 p-6 rounded-lg shadow-lg ${className}`}>
      <h3 className="text-xl font-semibold text-white mb-4">Daily Actual Water Volume (kL)</h3>
      <ResponsiveContainer width="100%" height={300}>
        <AreaChart data={data}>
          <CartesianGrid strokeDasharray="3 3" stroke={chartTheme.grid} />
          <XAxis
            dataKey="date"
            stroke={chartTheme.text}
            tickFormatter={formatDate}
            angle={-45}
            textAnchor="end"
            height={60}
          />
          <YAxis
            stroke={chartTheme.text}
            tickFormatter={(value) => `${(value / 1000).toFixed(0)}k`}
          />
          <Tooltip
            contentStyle={{
              backgroundColor: '#1F2937',
              border: 'none',
              borderRadius: '8px',
              color: '#F3F4F6'
            }}
            formatter={(value: number) => [`${(value / 1000).toFixed(1)}k kL`, 'Volume']}
            labelFormatter={(label) => `Date: ${formatDate(label)}`}
          />
          <Area
            type="monotone"
            dataKey="actualVolume"
            stroke={chartTheme.primary}
            fill={chartTheme.primary}
            fillOpacity={0.3}
            strokeWidth={2}
          />
        </AreaChart>
      </ResponsiveContainer>
    </div>
  );
}

export function CumulativeComparisonChart({ data, className = '' }: ChartProps) {
  const formatDate = (dateStr: string) => {
    return new Date(dateStr).toLocaleDateString('en-AU', {
      month: 'short',
      day: 'numeric'
    });
  };

  return (
    <div className={`bg-gray-800 p-6 rounded-lg shadow-lg ${className}`}>
      <h3 className="text-xl font-semibold text-white mb-4">Cumulative Volume: Actual vs Permitted</h3>
      <ResponsiveContainer width="100%" height={350}>
        <LineChart data={data}>
          <CartesianGrid strokeDasharray="3 3" stroke={chartTheme.grid} />
          <XAxis
            dataKey="date"
            stroke={chartTheme.text}
            tickFormatter={formatDate}
            angle={-45}
            textAnchor="end"
            height={60}
          />
          <YAxis
            stroke={chartTheme.text}
            tickFormatter={(value) => `${(value / 1000000).toFixed(1)}M`}
          />
          <Tooltip
            contentStyle={{
              backgroundColor: '#1F2937',
              border: 'none',
              borderRadius: '8px',
              color: '#F3F4F6'
            }}
            formatter={(value: number, name: string) => [
              `${(value / 1000000).toFixed(2)}M kL`,
              name === 'cumulativeTotal' ? 'Actual Total' : 'Permitted Volume'
            ]}
            labelFormatter={(label) => `Date: ${formatDate(label)}`}
          />
          <Legend />
          <Line
            type="monotone"
            dataKey="permittedVolume"
            stroke={chartTheme.secondary}
            strokeWidth={2}
            dot={false}
            name="Permitted Volume"
          />
          <Line
            type="monotone"
            dataKey="cumulativeTotal"
            stroke={chartTheme.warning}
            strokeWidth={2}
            dot={false}
            name="Actual Cumulative"
          />
        </LineChart>
      </ResponsiveContainer>
    </div>
  );
}

export function SeasonalBarChart({ data, className = '' }: ChartProps) {
  const seasonOrder = ['Summer', 'Autumn', 'Winter', 'Spring'];

  // Process data to include violation indicators
  const orderedData = seasonOrder.map(season => {
    const seasonData = data.find(item => item.season === season) || {
      season,
      avgTripsPerDay: 0,
      avgVolumePerDay: 0,
      totalTrips: 0,
      totalVolume: 0,
      totalDays: 0,
      highTripDays: 0,
      volumeExcessDays: 0
    };

    return seasonData;
  });

  // Find peak seasons for highlighting
  const peakTrips = orderedData.reduce((prev, current) =>
    prev.avgTripsPerDay > current.avgTripsPerDay ? prev : current
  );
  const peakVolume = orderedData.reduce((prev, current) =>
    prev.avgVolumePerDay > current.avgVolumePerDay ? prev : current
  );
  const mostViolations = orderedData.reduce((prev, current) =>
    (prev.highTripDays || 0) > (current.highTripDays || 0) ? prev : current
  );

  return (
    <div className={`bg-gray-800 p-6 rounded-lg shadow-lg ${className}`}>
      <h3 className="text-xl font-semibold text-white mb-4">
        Seasonal Analysis - Trips, Volume & Limit Violations by Season
      </h3>

      {/* Summary Cards with Indicators */}
      <div className="grid grid-cols-2 md:grid-cols-4 gap-3 mb-6">
        {orderedData.map((season) => (
          <div key={season.season} className="bg-gray-700 rounded-lg p-3">
            <div className="flex items-center justify-between mb-2">
              <h4 className="font-medium text-white">{season.season}</h4>
              <div className="flex gap-1">
                {season.season === peakTrips.season && (
                  <span className="text-xs bg-blue-600 px-2 py-1 rounded-full text-white">
                    Peak Trips
                  </span>
                )}
                {season.season === peakVolume.season && season.season !== peakTrips.season && (
                  <span className="text-xs bg-yellow-600 px-2 py-1 rounded-full text-white">
                    Peak Volume
                  </span>
                )}
                {season.season === mostViolations.season && (mostViolations.highTripDays || 0) > 0 && (
                  <span className="text-xs bg-red-600 px-2 py-1 rounded-full text-white">
                    Most Violations
                  </span>
                )}
              </div>
            </div>
            <div className="space-y-1 text-sm">
              <p className="text-gray-300">
                <span className="text-blue-400">{season.totalTrips || 0}</span> total trips
              </p>
              <p className="text-gray-300">
                <span className="text-yellow-400">{((season.totalVolume || 0) / 1000000).toFixed(1)}M</span> kL water
              </p>
              <p className="text-gray-300">
                <span className="text-green-400">{season.avgTripsPerDay?.toFixed(1) || '0.0'}</span> trips/day avg
              </p>
              <p className="text-gray-300">
                <span className="text-orange-400">{((season.avgVolumePerDay || 0) / 1000).toFixed(0)}k</span> kL/day avg
              </p>
              {(season.highTripDays || 0) > 0 && (
                <p className="text-red-400 font-medium">
                  ⚠ {season.highTripDays} days {'>'}3 trips
                </p>
              )}
            </div>
          </div>
        ))}
      </div>

      {/* Alert Summary */}
      <div className="bg-gray-700 rounded-lg p-4 mb-6">
        <h4 className="text-lg font-medium text-white mb-3 flex items-center gap-2">
          <AlertTriangle className="w-5 h-5 text-red-400" />
          Seasonal Violation Summary
        </h4>
        <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
          <div className="bg-red-900/30 border border-red-600/50 rounded-lg p-3">
            <p className="text-red-400 font-medium">Days with {'>'}3 Trips</p>
            <div className="space-y-1 mt-2">
              {orderedData.map(season => (
                <div key={season.season} className="flex justify-between text-sm">
                  <span className="text-gray-300">{season.season}:</span>
                  <span className={`font-medium ${(season.highTripDays || 0) > 0 ? 'text-red-400' : 'text-green-400'}`}>
                    {season.highTripDays || 0} days
                  </span>
                </div>
              ))}
            </div>
          </div>

          <div className="bg-yellow-900/30 border border-yellow-600/50 rounded-lg p-3">
            <p className="text-yellow-400 font-medium">Peak Activity Seasons</p>
            <div className="space-y-1 mt-2">
              <p className="text-sm text-gray-300">
                Highest Trips: <span className="text-blue-400 font-medium">{peakTrips.season}</span>
              </p>
              <p className="text-sm text-gray-300">
                Highest Volume: <span className="text-yellow-400 font-medium">{peakVolume.season}</span>
              </p>
              <p className="text-sm text-gray-300">
                Most Violations: <span className="text-red-400 font-medium">{mostViolations.season}</span>
              </p>
            </div>
          </div>

          <div className="bg-blue-900/30 border border-blue-600/50 rounded-lg p-3">
            <p className="text-blue-400 font-medium">Compliance Rate by Season</p>
            <div className="space-y-1 mt-2">
              {orderedData.map(season => {
                const violationRate = season.totalDays > 0
                  ? ((season.highTripDays || 0) / season.totalDays * 100).toFixed(1)
                  : '0.0';
                return (
                  <div key={season.season} className="flex justify-between text-sm">
                    <span className="text-gray-300">{season.season}:</span>
                    <span className={`font-medium ${parseFloat(violationRate) > 10 ? 'text-red-400' : 'text-green-400'}`}>
                      {violationRate}% violations
                    </span>
                  </div>
                );
              })}
            </div>
          </div>
        </div>
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
        {/* Trips Chart */}
        <div>
          <h4 className="text-lg font-medium text-white mb-3">
            Average Daily Trips by Season
          </h4>
          <ResponsiveContainer width="100%" height={300}>
            <BarChart data={orderedData}>
              <CartesianGrid strokeDasharray="3 3" stroke={chartTheme.grid} />
              <XAxis
                dataKey="season"
                stroke={chartTheme.text}
                tick={{ fontSize: 12 }}
              />
              <YAxis
                stroke={chartTheme.text}
                tick={{ fontSize: 12 }}
              />
              <Tooltip
                contentStyle={{
                  backgroundColor: '#1F2937',
                  border: 'none',
                  borderRadius: '8px',
                  color: '#F3F4F6'
                }}
                formatter={(value: number) => [`${value.toFixed(1)} trips/day`, 'Average per day']}
                labelFormatter={(label) => `Season: ${label}`}
              />
              <Bar
                dataKey="avgTripsPerDay"
                fill={chartTheme.primary}
                radius={[4, 4, 0, 0]}
              />
            </BarChart>
          </ResponsiveContainer>
        </div>

        {/* Volume Chart */}
        <div>
          <h4 className="text-lg font-medium text-white mb-3">
            Average Daily Volume by Season (kL)
          </h4>
          <ResponsiveContainer width="100%" height={300}>
            <BarChart data={orderedData}>
              <CartesianGrid strokeDasharray="3 3" stroke={chartTheme.grid} />
              <XAxis
                dataKey="season"
                stroke={chartTheme.text}
                tick={{ fontSize: 12 }}
              />
              <YAxis
                stroke={chartTheme.text}
                tickFormatter={(value) => `${(value / 1000).toFixed(0)}k`}
                tick={{ fontSize: 12 }}
              />
              <Tooltip
                contentStyle={{
                  backgroundColor: '#1F2937',
                  border: 'none',
                  borderRadius: '8px',
                  color: '#F3F4F6'
                }}
                formatter={(value: number) => [`${(value / 1000).toFixed(1)}k kL/day`, 'Average volume']}
                labelFormatter={(label) => `Season: ${label}`}
              />
              <Bar
                dataKey="avgVolumePerDay"
                fill={chartTheme.accent}
                radius={[4, 4, 0, 0]}
              />
            </BarChart>
          </ResponsiveContainer>
        </div>
      </div>
    </div>
  );
}

export function TripsOverTimeChart({ data, className = '' }: ChartProps) {
  const formatDate = (dateStr: string) => {
    return new Date(dateStr).toLocaleDateString('en-AU', {
      month: 'short',
      day: 'numeric'
    });
  };

  return (
    <div className={`bg-gray-800 p-6 rounded-lg shadow-lg ${className}`}>
      <h3 className="text-xl font-semibold text-white mb-4">Daily Trips Over Time</h3>
      <ResponsiveContainer width="100%" height={300}>
        <BarChart data={data}>
          <CartesianGrid strokeDasharray="3 3" stroke={chartTheme.grid} />
          <XAxis
            dataKey="date"
            stroke={chartTheme.text}
            tickFormatter={formatDate}
            angle={-45}
            textAnchor="end"
            height={60}
          />
          <YAxis stroke={chartTheme.text} />
          <Tooltip
            contentStyle={{
              backgroundColor: '#1F2937',
              border: 'none',
              borderRadius: '8px',
              color: '#F3F4F6'
            }}
            formatter={(value: number) => [`${value}`, 'Trips']}
            labelFormatter={(label) => `Date: ${formatDate(label)}`}
          />
          <Bar
            dataKey="trips"
            fill={chartTheme.secondary}
            radius={[2, 2, 0, 0]}
          />
        </BarChart>
      </ResponsiveContainer>
    </div>
  );
}