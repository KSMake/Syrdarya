import { AlertTriangle, TrendingUp, Shield, Clock, Target } from 'lucide-react';
import { WaterExtractionData } from '../utils/dataProcessing';

interface RiskManagementDashboardProps {
  data: WaterExtractionData[];
  className?: string;
}

interface RiskMetrics {
  currentRiskLevel: 'Low' | 'Medium' | 'High' | 'Critical';
  riskScore: number;
  daysUntilLimit: number;
  violationProbability: number;
  complianceScore: number;
  utilizationRate: number;
  criticalAlerts: Array<{
    id: string;
    type: 'warning' | 'danger' | 'info';
    priority: 'high' | 'medium' | 'low';
    message: string;
    recommendation: string;
    impact: string;
  }>;
  trendAnalysis: {
    direction: 'increasing' | 'decreasing' | 'stable';
    rate: number;
    confidence: number;
  };
  earlyWarnings: Array<{
    type: string;
    message: string;
    timeframe: string;
    action: string;
  }>;
}

export function RiskManagementDashboard({ data, className = '' }: RiskManagementDashboardProps) {
  const calculateRiskMetrics = (): RiskMetrics => {
    if (data.length === 0) {
      return {
        currentRiskLevel: 'Low',
        riskScore: 0,
        daysUntilLimit: 999,
        violationProbability: 0,
        complianceScore: 100,
        utilizationRate: 0,
        criticalAlerts: [],
        trendAnalysis: { direction: 'stable', rate: 0, confidence: 0 },
        earlyWarnings: []
      };
    }

    const lastEntry = data[data.length - 1];
    const currentUtilization = (lastEntry.cumulativeTotal / lastEntry.permittedVolume) * 100;

    // Calculate daily average extraction rate (last 30 days)
    const last30Days = data.slice(-30);
    const avgDailyExtraction = last30Days.reduce((sum, entry) => sum + entry.actualVolume, 0) / last30Days.length;

    // Calculate days until limit is reached
    const remainingVolume = lastEntry.permittedVolume - lastEntry.cumulativeTotal;
    const daysUntilLimit = remainingVolume > 0 ? Math.floor(remainingVolume / avgDailyExtraction) : 0;

    // Risk level calculation
    let currentRiskLevel: 'Low' | 'Medium' | 'High' | 'Critical';
    if (currentUtilization >= 100) currentRiskLevel = 'Critical';
    else if (currentUtilization >= 90) currentRiskLevel = 'High';
    else if (currentUtilization >= 75) currentRiskLevel = 'Medium';
    else currentRiskLevel = 'Low';

    // Violation probability (based on current trend and remaining capacity)
    const last7Days = data.slice(-7);
    const recentAvg = last7Days.reduce((sum, entry) => sum + entry.actualVolume, 0) / last7Days.length;
    const violationProbability = Math.min(100, Math.max(0, (recentAvg * 30 / remainingVolume) * 100));

    // Compliance score (percentage of days within limits)
    const totalDays = data.length;
    const violationDays = data.filter(entry => entry.trips > 3).length;
    const complianceScore = Math.max(0, 100 - (violationDays / totalDays * 100));

    // Trend analysis
    const first15Days = data.slice(0, 15);
    const last15Days = data.slice(-15);
    const firstAvg = first15Days.reduce((sum, entry) => sum + entry.actualVolume, 0) / first15Days.length;
    const lastAvg = last15Days.reduce((sum, entry) => sum + entry.actualVolume, 0) / last15Days.length;
    const trendRate = ((lastAvg - firstAvg) / firstAvg) * 100;

    let trendDirection: 'increasing' | 'decreasing' | 'stable';
    if (Math.abs(trendRate) < 5) trendDirection = 'stable';
    else if (trendRate > 0) trendDirection = 'increasing';
    else trendDirection = 'decreasing';

    // Generate critical alerts
    const criticalAlerts = [];

    if (currentUtilization >= 95) {
      criticalAlerts.push({
        type: 'danger' as const,
        message: `Critical: ${currentUtilization.toFixed(1)}% of permitted volume used`,
        recommendation: 'Immediate reduction in extraction required. Consider alternative sources.'
      });
    }

    if (daysUntilLimit <= 30 && daysUntilLimit > 0) {
      criticalAlerts.push({
        type: 'warning' as const,
        message: `Warning: Approaching limit in ${daysUntilLimit} days at current rate`,
        recommendation: 'Reduce daily extraction rate by 20% to extend timeline.'
      });
    }

    if (violationDays > totalDays * 0.1) {
      criticalAlerts.push({
        type: 'warning' as const,
        message: `${violationDays} days exceeded 3 trips limit (${(violationDays/totalDays*100).toFixed(1)}%)`,
        recommendation: 'Review operational procedures to maintain trip limits.'
      });
    }

    if (trendDirection === 'increasing' && trendRate > 15) {
      criticalAlerts.push({
        type: 'warning' as const,
        message: `Extraction rate increasing by ${trendRate.toFixed(1)}%`,
        recommendation: 'Monitor closely and consider proactive measures.'
      });
    }

    return {
      currentRiskLevel,
      riskScore: currentUtilization + (violationDays / totalDays * 100) * 0.5,
      daysUntilLimit,
      violationProbability,
      complianceScore,
      utilizationRate: currentUtilization,
      criticalAlerts: criticalAlerts.map((alert, index) => ({
        id: `alert-${index}`,
        type: alert.type,
        priority: alert.type === 'danger' ? 'high' : 'medium' as const,
        message: alert.message,
        recommendation: alert.recommendation,
        impact: 'Risk assessment impact'
      })),
      trendAnalysis: {
        direction: trendDirection,
        rate: Math.abs(trendRate),
        confidence: Math.min(100, Math.abs(trendRate) * 10)
      },
      earlyWarnings: []
    };
  };

  const metrics = calculateRiskMetrics();

  const getRiskColor = (level: string) => {
    switch (level) {
      case 'Low': return 'text-green-400 bg-green-900/30 border-green-600/50';
      case 'Medium': return 'text-yellow-400 bg-yellow-900/30 border-yellow-600/50';
      case 'High': return 'text-orange-400 bg-orange-900/30 border-orange-600/50';
      case 'Critical': return 'text-red-400 bg-red-900/30 border-red-600/50';
      default: return 'text-gray-400 bg-gray-900/30 border-gray-600/50';
    }
  };

  const getTrendIcon = (direction: string) => {
    switch (direction) {
      case 'increasing': return <TrendingUp className="w-4 h-4 text-red-400" />;
      case 'decreasing': return <TrendingUp className="w-4 h-4 text-green-400 rotate-180" />;
      default: return <Target className="w-4 h-4 text-blue-400" />;
    }
  };

  return (
    <div className={`bg-gray-800 p-6 rounded-lg shadow-lg border border-gray-700 ${className}`}>
      <div className="flex items-center gap-3 mb-6">
        <Shield className="w-6 h-6 text-blue-400" />
        <h3 className="text-xl font-semibold text-white">Risk Management Dashboard</h3>
      </div>

      {/* Risk Level Overview */}
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-4 mb-6">
        <div className={`p-4 rounded-lg border ${getRiskColor(metrics.currentRiskLevel)}`}>
          <div className="flex items-center justify-between mb-2">
            <span className="text-sm font-medium">Risk Level</span>
            <AlertTriangle className="w-5 h-5" />
          </div>
          <p className="text-2xl font-bold">{metrics.currentRiskLevel}</p>
        </div>

        <div className="bg-gray-700 p-4 rounded-lg border border-gray-600">
          <div className="flex items-center justify-between mb-2">
            <span className="text-sm font-medium text-gray-300">Days Until Limit</span>
            <Clock className="w-5 h-5 text-blue-400" />
          </div>
          <p className="text-2xl font-bold text-white">
            {metrics.daysUntilLimit === 999 ? '∞' : metrics.daysUntilLimit}
          </p>
        </div>

        <div className="bg-gray-700 p-4 rounded-lg border border-gray-600">
          <div className="flex items-center justify-between mb-2">
            <span className="text-sm font-medium text-gray-300">Violation Probability</span>
            <Target className="w-5 h-5 text-yellow-400" />
          </div>
          <p className="text-2xl font-bold text-white">{metrics.violationProbability.toFixed(1)}%</p>
        </div>

        <div className="bg-gray-700 p-4 rounded-lg border border-gray-600">
          <div className="flex items-center justify-between mb-2">
            <span className="text-sm font-medium text-gray-300">Compliance Score</span>
            <Shield className="w-5 h-5 text-green-400" />
          </div>
          <p className="text-2xl font-bold text-white">{metrics.complianceScore.toFixed(1)}%</p>
        </div>
      </div>

      {/* Trend Analysis */}
      <div className="bg-gray-700 rounded-lg p-4 mb-6">
        <div className="flex items-center gap-2 mb-3">
          {getTrendIcon(metrics.trendAnalysis.direction)}
          <h4 className="font-semibold text-white">Trend Analysis</h4>
        </div>
        <p className="text-gray-300">
          Extraction rate is <span className="font-medium text-white">{metrics.trendAnalysis.direction}</span>
          {metrics.trendAnalysis.rate > 0 && (
            <span> by {metrics.trendAnalysis.rate.toFixed(1)}%</span>
          )}
        </p>
      </div>

      {/* Critical Alerts */}
      {metrics.criticalAlerts.length > 0 && (
        <div className="space-y-4">
          <h4 className="font-semibold text-white flex items-center gap-2">
            <AlertTriangle className="w-5 h-5 text-red-400" />
            Critical Alerts & Recommendations
          </h4>

          {metrics.criticalAlerts.map((alert, index) => (
            <div
              key={index}
              className={`p-4 rounded-lg border ${
                alert.type === 'danger'
                  ? 'bg-red-900/30 border-red-600/50'
                  : 'bg-yellow-900/30 border-yellow-600/50'
              }`}
            >
              <div className="flex items-start gap-3">
                <AlertTriangle className={`w-5 h-5 mt-0.5 ${
                  alert.type === 'danger' ? 'text-red-400' : 'text-yellow-400'
                }`} />
                <div className="flex-1">
                  <p className={`font-medium ${
                    alert.type === 'danger' ? 'text-red-400' : 'text-yellow-400'
                  }`}>
                    {alert.message}
                  </p>
                  <p className="text-gray-300 mt-1 text-sm">
                    <strong>Recommendation:</strong> {alert.recommendation}
                  </p>
                </div>
              </div>
            </div>
          ))}
        </div>
      )}

      {/* No Alerts State */}
      {metrics.criticalAlerts.length === 0 && (
        <div className="bg-green-900/30 border border-green-600/50 rounded-lg p-4">
          <div className="flex items-center gap-3">
            <Shield className="w-5 h-5 text-green-400" />
            <div>
              <p className="font-medium text-green-400">All Systems Normal</p>
              <p className="text-gray-300 text-sm">No critical alerts at this time. Continue monitoring.</p>
            </div>
          </div>
        </div>
      )}
    </div>
  );
}