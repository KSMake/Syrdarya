import { Calendar, Filter, AlertTriangle } from 'lucide-react';

interface FilterControlsProps {
  filters: {
    startDate: string;
    endDate: string;
    minTrips: number;
    maxTrips: number;
    highlightThreshold: number;
    timeframe: 'daily' | 'weekly' | 'monthly';
  };
  onFilterChange: (filters: any) => void;
  dataRange: {
    minDate: string;
    maxDate: string;
    minTrips: number;
    maxTrips: number;
  };
}

export function FilterControls({ filters, onFilterChange, dataRange }: FilterControlsProps) {
  const handleInputChange = (field: string, value: any) => {
    onFilterChange({
      ...filters,
      [field]: value
    });
  };

  const resetFilters = () => {
    onFilterChange({
      startDate: dataRange.minDate,
      endDate: dataRange.maxDate,
      minTrips: 0,
      maxTrips: 10,
      highlightThreshold: 3,
      timeframe: 'daily'
    });
  };

  return (
    <div className="bg-gray-800 p-6 rounded-lg shadow-lg">
      <div className="flex items-center gap-2 mb-6">
        <Filter className="w-5 h-5 text-blue-400" />
        <h3 className="text-xl font-semibold text-white">Filter Controls</h3>
      </div>

      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 xl:grid-cols-4 gap-6">
        {/* Date Range */}
        <div className="space-y-4">
          <div className="flex items-center gap-2 text-gray-300">
            <Calendar className="w-4 h-4" />
            <span className="font-medium">Date Range</span>
          </div>

          <div className="space-y-3">
            <div>
              <label className="block text-sm text-gray-400 mb-1">From</label>
              <input
                type="date"
                value={filters.startDate}
                min={dataRange.minDate}
                max={dataRange.maxDate}
                onChange={(e) => handleInputChange('startDate', e.target.value)}
                className="w-full px-3 py-2 bg-gray-700 border border-gray-600 rounded-md text-white focus:outline-none focus:ring-2 focus:ring-blue-500"
              />
            </div>

            <div>
              <label className="block text-sm text-gray-400 mb-1">To</label>
              <input
                type="date"
                value={filters.endDate}
                min={dataRange.minDate}
                max={dataRange.maxDate}
                onChange={(e) => handleInputChange('endDate', e.target.value)}
                className="w-full px-3 py-2 bg-gray-700 border border-gray-600 rounded-md text-white focus:outline-none focus:ring-2 focus:ring-blue-500"
              />
            </div>
          </div>
        </div>

        {/* Trips Filter */}
        <div className="space-y-4">
          <div className="flex items-center gap-2 text-gray-300">
            <AlertTriangle className="w-4 h-4" />
            <span className="font-medium">Trips Range</span>
          </div>

          <div className="space-y-3">
            <div>
              <label className="block text-sm text-gray-400 mb-1">
                Min Trips: {filters.minTrips}
              </label>
              <input
                type="range"
                min="0"
                max="10"
                value={filters.minTrips}
                onChange={(e) => handleInputChange('minTrips', parseInt(e.target.value))}
                className="w-full h-2 bg-gray-600 rounded-lg appearance-none cursor-pointer slider"
              />
            </div>

            <div>
              <label className="block text-sm text-gray-400 mb-1">
                Max Trips: {filters.maxTrips}
              </label>
              <input
                type="range"
                min="0"
                max="10"
                value={filters.maxTrips}
                onChange={(e) => handleInputChange('maxTrips', parseInt(e.target.value))}
                className="w-full h-2 bg-gray-600 rounded-lg appearance-none cursor-pointer slider"
              />
            </div>
          </div>
        </div>

        {/* Threshold Highlighting */}
        <div className="space-y-4">
          <div className="text-gray-300">
            <span className="font-medium">Alert Threshold</span>
          </div>

          <div>
            <label className="block text-sm text-gray-400 mb-1">
              Highlight {filters.highlightThreshold}+ trips/day
            </label>
            <input
              type="range"
              min="1"
              max="6"
              value={filters.highlightThreshold}
              onChange={(e) => handleInputChange('highlightThreshold', parseInt(e.target.value))}
              className="w-full h-2 bg-gray-600 rounded-lg appearance-none cursor-pointer slider"
            />
            <div className="text-xs text-gray-500 mt-1">
              Days exceeding this threshold will be highlighted
            </div>
          </div>
        </div>

        {/* Time Aggregation */}
        <div className="space-y-4">
          <div className="text-gray-300">
            <span className="font-medium">Time Grouping</span>
          </div>

          <div className="space-y-2">
            {[
              { value: 'daily', label: 'Daily View' },
              { value: 'weekly', label: 'Weekly View' },
              { value: 'monthly', label: 'Monthly View' }
            ].map((option) => (
              <label key={option.value} className="flex items-center gap-2 text-gray-300 cursor-pointer">
                <input
                  type="radio"
                  name="timeframe"
                  value={option.value}
                  checked={filters.timeframe === option.value}
                  onChange={(e) => handleInputChange('timeframe', e.target.value)}
                  className="w-4 h-4 text-blue-600 bg-gray-700 border-gray-600 focus:ring-blue-500"
                />
                <span className="text-sm">{option.label}</span>
              </label>
            ))}
          </div>
        </div>
      </div>

      {/* Reset Button */}
      <div className="mt-6 pt-4 border-t border-gray-700">
        <button
          onClick={resetFilters}
          className="px-4 py-2 bg-gray-600 hover:bg-gray-500 text-white rounded-md transition-colors duration-200 text-sm"
        >
          Reset All Filters
        </button>
      </div>

      {/* Filter Summary */}
      <div className="mt-4 p-3 bg-gray-700 rounded-md">
        <div className="text-sm text-gray-300">
          <div className="flex flex-wrap gap-4">
            <span>Period: {filters.startDate} to {filters.endDate}</span>
            <span>Trips: {filters.minTrips}-{filters.maxTrips}</span>
            <span>View: {filters.timeframe}</span>
            <span>Alert: {filters.highlightThreshold}+ trips</span>
          </div>
        </div>
      </div>
    </div>
  );
}

export default FilterControls;