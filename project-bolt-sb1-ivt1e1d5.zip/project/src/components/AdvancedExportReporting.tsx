import { Download, FileText, Calendar, BarChart3, Printer, Clock } from 'lucide-react';
import { WaterExtractionData } from '../utils/dataProcessing';

// Simple date formatting without external dependencies
const formatDate = (date: Date): string => {
  return date.toISOString().split('T')[0]; // Returns YYYY-MM-DD
};

const formatDateLong = (date: Date): string => {
  return date.toLocaleDateString('en-US', {
    weekday: 'long',
    year: 'numeric',
    month: 'long',
    day: 'numeric'
  });
};

const formatTime = (date: Date): string => {
  return date.toLocaleTimeString('en-US', {
    hour: '2-digit',
    minute: '2-digit'
  });
};

interface AdvancedExportReportingProps {
  data: WaterExtractionData[];
  filteredData: WaterExtractionData[];
  seasonalData: any[];
  statsData: any;
  className?: string;
}

export function AdvancedExportReporting({
  data,
  filteredData,
  seasonalData,
  statsData,
  className = ''
}: AdvancedExportReportingProps) {

  // Native browser download function
  const downloadFile = (content: string, filename: string, type: string = 'text/plain') => {
    const blob = new Blob([content], { type: `${type};charset=utf-8` });
    const url = URL.createObjectURL(blob);
    const link = document.createElement('a');
    link.href = url;
    link.download = filename;
    document.body.appendChild(link);
    link.click();
    document.body.removeChild(link);
    URL.revokeObjectURL(url);
  };

  // Enhanced CSV Export with more details
  const generateEnhancedCSV = (dataToExport: WaterExtractionData[], filename: string) => {
    const headers = [
      'Date',
      'Day of Week',
      'Trips',
      'Daily Limit (kL)',
      'Permitted Volume (kL)',
      'Actual Volume (kL)',
      'Cumulative Total (kL)',
      'Utilization Rate (%)',
      'Season',
      'Compliance Status',
      'Days Over Limit',
      'Volume Over Limit (kL)',
      'Risk Level'
    ];

    const csvData = dataToExport.map(row => {
      const utilizationRate = (row.cumulativeTotal / row.permittedVolume * 100).toFixed(2);
      const isViolation = row.trips > 3;
      const volumeOverLimit = isViolation ? (row.actualVolume - row.dailyLimit).toFixed(0) : '0';

      let riskLevel = 'Low';
      if (parseFloat(utilizationRate) >= 95) riskLevel = 'Critical';
      else if (parseFloat(utilizationRate) >= 85) riskLevel = 'High';
      else if (parseFloat(utilizationRate) >= 70) riskLevel = 'Medium';

      return [
        row.date,
        new Date(row.date).toLocaleDateString('en-US', { weekday: 'long' }),
        row.trips.toString(),
        row.dailyLimit.toString(),
        row.permittedVolume.toString(),
        row.actualVolume.toString(),
        row.cumulativeTotal.toString(),
        utilizationRate,
        row.season,
        isViolation ? 'Violation' : 'Compliant',
        isViolation ? '1' : '0',
        volumeOverLimit,
        riskLevel
      ];
    });

    const csvContent = [headers, ...csvData]
      .map(row => row.map(cell => `"${cell}"`).join(','))
      .join('\n');

    downloadFile(csvContent, `${filename}.csv`, 'text/csv');
  };

  // Excel-style CSV with summary statistics
  const generateExcelStyleReport = () => {
    const utilizationRate = (statsData.totalActualVolume / statsData.totalPermittedVolume) * 100;
    const violationRate = (statsData.highTripDays / statsData.totalDays) * 100;

    const summaryHeaders = [
      'Metric', 'Value', 'Unit', 'Status'
    ];

    const summaryData = [
      ['Analysis Period Start', data[0]?.date || 'N/A', 'Date', 'Info'],
      ['Analysis Period End', data[data.length - 1]?.date || 'N/A', 'Date', 'Info'],
      ['Total Extraction Days', statsData.totalDays.toString(), 'Days', 'Info'],
      ['Total Trips', statsData.totalTrips.toLocaleString(), 'Trips', 'Info'],
      ['Total Volume Extracted', (statsData.totalActualVolume / 1000000).toFixed(2), 'Million kL', 'Info'],
      ['Current Utilization Rate', utilizationRate.toFixed(2), 'Percentage', utilizationRate >= 90 ? 'Warning' : 'OK'],
      ['Compliance Rate', (100 - violationRate).toFixed(2), 'Percentage', violationRate > 10 ? 'Warning' : 'OK'],
      ['High Trip Days', statsData.highTripDays.toString(), 'Days', statsData.highTripDays > 0 ? 'Warning' : 'OK'],
      ['Peak Activity Season', statsData.peakSeason || 'N/A', 'Season', 'Info']
    ];

    // Seasonal breakdown
    const seasonalHeaders = [
      'Season', 'Total Days', 'Total Trips', 'Total Volume (ML)', 'Avg Trips/Day', 'Violation Days', 'Violation Rate (%)'
    ];

    const seasonalSummary = seasonalData.map(season => [
      season.season,
      (season.totalDays || 0).toString(),
      (season.totalTrips || 0).toString(),
      ((season.totalVolume || 0) / 1000000).toFixed(2),
      (season.avgTripsPerDay || 0).toFixed(1),
      (season.highTripDays || 0).toString(),
      season.totalDays > 0 ? ((season.highTripDays || 0) / season.totalDays * 100).toFixed(1) : '0'
    ]);

    // Combine all sections
    const reportContent = [
      ['WATER EXTRACTION - EXECUTIVE SUMMARY'],
      ['Generated on:', formatDateLong(new Date())],
      [''],
      summaryHeaders,
      ...summaryData,
      [''],
      ['SEASONAL ANALYSIS'],
      seasonalHeaders,
      ...seasonalSummary,
      [''],
      ['DETAILED DAILY DATA'],
      ['Date', 'Trips', 'Volume (kL)', 'Cumulative (kL)', 'Utilization %', 'Compliance']
    ];

    // Add daily data
    filteredData.forEach(row => {
      reportContent.push([
        row.date,
        row.trips.toString(),
        row.actualVolume.toString(),
        row.cumulativeTotal.toString(),
        ((row.cumulativeTotal / row.permittedVolume) * 100).toFixed(1),
        row.trips > 3 ? 'Violation' : 'Compliant'
      ]);
    });

    const csvContent = reportContent
      .map(row => row.map(cell => `"${cell || ''}"`).join(','))
      .join('\n');

    const filename = `executive_report_${formatDate(new Date())}`;
    downloadFile(csvContent, `${filename}.csv`, 'text/csv');
  };

  // PDF Generation using browser print functionality
  const generatePDFReport = () => {
    const utilizationRate = (statsData.totalActualVolume / statsData.totalPermittedVolume) * 100;
    const violationRate = (statsData.highTripDays / statsData.totalDays) * 100;

    const printWindow = window.open('', '_blank');
    if (!printWindow) {
      alert('Please allow pop-ups to generate PDF reports');
      return;
    }

    const htmlContent = `
    <!DOCTYPE html>
    <html>
    <head>
        <title>Water Extraction Analytics Report</title>
        <style>
            body { font-family: Arial, sans-serif; margin: 40px; color: #333; }
            .header { text-align: center; border-bottom: 3px solid #2563eb; padding-bottom: 20px; margin-bottom: 30px; }
            .title { font-size: 28px; font-weight: bold; color: #1e40af; margin-bottom: 10px; }
            .subtitle { font-size: 14px; color: #6b7280; }
            .section { margin-bottom: 30px; }
            .section-title { font-size: 18px; font-weight: bold; color: #1e40af; margin-bottom: 15px; border-bottom: 2px solid #e5e7eb; padding-bottom: 5px; }
            .metric-grid { display: grid; grid-template-columns: repeat(2, 1fr); gap: 15px; margin-bottom: 20px; }
            .metric-card { border: 1px solid #d1d5db; padding: 15px; border-radius: 8px; background: #f9fafb; }
            .metric-label { font-size: 12px; color: #6b7280; font-weight: bold; }
            .metric-value { font-size: 24px; font-weight: bold; color: #1f2937; margin-top: 5px; }
            .metric-unit { font-size: 14px; color: #9ca3af; }
            .risk-critical { color: #dc2626; }
            .risk-high { color: #ea580c; }
            .risk-medium { color: #d97706; }
            .risk-low { color: #16a34a; }
            .table { width: 100%; border-collapse: collapse; margin-top: 15px; }
            .table th, .table td { border: 1px solid #d1d5db; padding: 8px 12px; text-align: left; }
            .table th { background-color: #f3f4f6; font-weight: bold; }
            .violation { background-color: #fef2f2; color: #dc2626; }
            .compliant { background-color: #f0fdf4; color: #16a34a; }
            .recommendations { background-color: #fef3c7; padding: 15px; border-radius: 8px; border-left: 4px solid #f59e0b; }
            .alert { background-color: #fee2e2; padding: 15px; border-radius: 8px; border-left: 4px solid #dc2626; margin-bottom: 15px; }
            @media print {
                body { margin: 20px; }
                .section { page-break-inside: avoid; }
                .metric-grid { display: block; }
                .metric-card { margin-bottom: 10px; display: inline-block; width: 48%; margin-right: 2%; }
            }
        </style>
    </head>
    <body>
        <div class="header">
            <div class="title">Water Extraction Analytics Report</div>
            <div class="subtitle">Generated on ${formatDateLong(new Date())}</div>
            <div class="subtitle">Analysis Period: ${data[0]?.date || 'N/A'} to ${data[data.length - 1]?.date || 'N/A'}</div>
        </div>

        <div class="section">
            <div class="section-title">Executive Summary</div>
            <div class="metric-grid">
                <div class="metric-card">
                    <div class="metric-label">Current Utilization</div>
                    <div class="metric-value ${utilizationRate >= 90 ? 'risk-critical' : utilizationRate >= 75 ? 'risk-high' : utilizationRate >= 60 ? 'risk-medium' : 'risk-low'}">${utilizationRate.toFixed(1)}<span class="metric-unit">%</span></div>
                </div>
                <div class="metric-card">
                    <div class="metric-label">Total Volume Extracted</div>
                    <div class="metric-value">${(statsData.totalActualVolume / 1000000).toFixed(1)}<span class="metric-unit">M kL</span></div>
                </div>
                <div class="metric-card">
                    <div class="metric-label">Compliance Rate</div>
                    <div class="metric-value ${violationRate > 10 ? 'risk-high' : 'risk-low'}">${(100 - violationRate).toFixed(1)}<span class="metric-unit">%</span></div>
                </div>
                <div class="metric-card">
                    <div class="metric-label">Total Trips</div>
                    <div class="metric-value">${statsData.totalTrips.toLocaleString()}<span class="metric-unit">trips</span></div>
                </div>
            </div>
        </div>

        ${utilizationRate >= 90 ? `
        <div class="alert">
            <strong>⚠️ HIGH UTILIZATION ALERT:</strong> Current utilization of ${utilizationRate.toFixed(1)}% is approaching critical levels.
            Immediate action recommended to avoid permit violations.
        </div>` : ''}

        ${violationRate > 10 ? `
        <div class="alert">
            <strong>⚠️ COMPLIANCE CONCERN:</strong> ${violationRate.toFixed(1)}% violation rate exceeds acceptable thresholds.
            Review operational procedures immediately.
        </div>` : ''}

        <div class="section">
            <div class="section-title">Seasonal Analysis</div>
            <table class="table">
                <thead>
                    <tr>
                        <th>Season</th>
                        <th>Total Days</th>
                        <th>Total Trips</th>
                        <th>Volume (M kL)</th>
                        <th>Avg/Day</th>
                        <th>Violations</th>
                        <th>Rate %</th>
                    </tr>
                </thead>
                <tbody>
                    ${seasonalData.map(season => `
                    <tr>
                        <td>${season.season}</td>
                        <td>${season.totalDays || 0}</td>
                        <td>${season.totalTrips || 0}</td>
                        <td>${((season.totalVolume || 0) / 1000000).toFixed(2)}</td>
                        <td>${(season.avgTripsPerDay || 0).toFixed(1)}</td>
                        <td>${season.highTripDays || 0}</td>
                        <td>${season.totalDays > 0 ? ((season.highTripDays || 0) / season.totalDays * 100).toFixed(1) : 0}%</td>
                    </tr>
                    `).join('')}
                </tbody>
            </table>
        </div>

        <div class="recommendations">
            <div class="section-title">Key Recommendations</div>
            <ul>
                ${utilizationRate >= 95 ? '<li><strong>URGENT:</strong> Reduce extraction immediately to avoid permit violation</li>' : ''}
                ${violationRate > 10 ? '<li>Review and strengthen operational procedures to maintain daily trip limits</li>' : ''}
                ${utilizationRate >= 80 ? '<li>Consider alternative water sources for peak demand periods</li>' : ''}
                <li>Continue monitoring daily extraction rates closely</li>
                <li>Implement early warning system for approaching limits</li>
                <li>Provide regular training to operators on permit requirements</li>
            </ul>
        </div>

        <div class="section">
            <div class="section-title">Recent Activity Summary (Last 30 Days)</div>
            <table class="table">
                <thead>
                    <tr>
                        <th>Date</th>
                        <th>Trips</th>
                        <th>Volume (kL)</th>
                        <th>Status</th>
                    </tr>
                </thead>
                <tbody>
                    ${filteredData.slice(-30).map(row => `
                    <tr>
                        <td>${row.date}</td>
                        <td>${row.trips}</td>
                        <td>${row.actualVolume}</td>
                        <td class="${row.trips > 3 ? 'violation' : 'compliant'}">${row.trips > 3 ? 'Violation' : 'Compliant'}</td>
                    </tr>
                    `).join('')}
                </tbody>
            </table>
        </div>
    </body>
    </html>
    `;

    printWindow.document.write(htmlContent);
    printWindow.document.close();

    // Wait for content to load then trigger print
    setTimeout(() => {
      printWindow.print();
    }, 1000);
  };

  // Automated Report Scheduling (Weekly)
  const generateWeeklyReport = () => {
    const lastWeek = filteredData.slice(-7);
    const weeklyFilename = `weekly_report_${formatDate(new Date())}`;
    generateEnhancedCSV(lastWeek, weeklyFilename);
  };

  // Automated Report Scheduling (Monthly)
  const generateMonthlyReport = () => {
    const lastMonth = filteredData.slice(-30);
    const monthlyFilename = `monthly_report_${formatDate(new Date())}`;
    generateEnhancedCSV(lastMonth, monthlyFilename);
  };

  // Custom Date Range Analysis
  const generateCustomRangeAnalysis = () => {
    const customFilename = `custom_analysis_${formatDate(new Date())}`;

    // Enhanced analysis for filtered data
    const filteredStats = {
      totalDays: filteredData.length,
      totalTrips: filteredData.reduce((sum, entry) => sum + entry.trips, 0),
      totalVolume: filteredData.reduce((sum, entry) => sum + entry.actualVolume, 0),
      violationDays: filteredData.filter(entry => entry.trips > 3).length,
      avgDailyVolume: filteredData.reduce((sum, entry) => sum + entry.actualVolume, 0) / filteredData.length
    };

    const analysisContent = `WATER EXTRACTION - CUSTOM RANGE ANALYSIS
Generated: ${formatDateLong(new Date())}
Analysis Period: ${filteredData[0]?.date || 'N/A'} to ${filteredData[filteredData.length - 1]?.date || 'N/A'}
========================================================================

RANGE SUMMARY
Total Days Analyzed: ${filteredStats.totalDays}
Total Trips: ${filteredStats.totalTrips.toLocaleString()}
Total Volume: ${(filteredStats.totalVolume / 1000000).toFixed(2)} Million kL
Average Daily Volume: ${filteredStats.avgDailyVolume.toFixed(0)} kL/day
Violation Days: ${filteredStats.violationDays}
Compliance Rate: ${((filteredStats.totalDays - filteredStats.violationDays) / filteredStats.totalDays * 100).toFixed(1)}%

DETAILED DAILY BREAKDOWN
Date,Trips,Volume (kL),Cumulative (kL),Utilization %,Status
${filteredData.map(row =>
  `${row.date},${row.trips},${row.actualVolume},${row.cumulativeTotal},${((row.cumulativeTotal / row.permittedVolume) * 100).toFixed(1)}%,${row.trips > 3 ? 'Violation' : 'Compliant'}`
).join('\n')}

========================================================================
Custom Analysis Report - Water Extraction Analytics
`;

    downloadFile(analysisContent, `${customFilename}.txt`, 'text/plain');
  };

  return (
    <div className={`bg-gray-800 p-6 rounded-lg shadow-lg border border-gray-700 ${className}`}>
      <div className="flex items-center gap-3 mb-6">
        <FileText className="w-6 h-6 text-green-400" />
        <h3 className="text-xl font-semibold text-white">Export & Reporting Suite</h3>
        <div className="ml-auto flex items-center gap-2 text-xs text-gray-400">
          <Clock className="w-4 h-4" />
          <span>Last updated: {formatTime(new Date())}</span>
        </div>
      </div>

      {/* Main Export Options */}
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4 mb-6">
        {/* PDF Report */}
        <button
          onClick={generatePDFReport}
          className="flex items-center gap-3 p-4 bg-red-900/30 border border-red-600/50 rounded-lg hover:bg-red-900/40 transition-colors group"
        >
          <Printer className="w-5 h-5 text-red-400 group-hover:scale-110 transition-transform" />
          <div className="text-left">
            <p className="font-medium text-red-400">PDF Report</p>
            <p className="text-sm text-gray-300">Professional analytics report</p>
          </div>
        </button>

        {/* Excel-Style Export */}
        <button
          onClick={generateExcelStyleReport}
          className="flex items-center gap-3 p-4 bg-green-900/30 border border-green-600/50 rounded-lg hover:bg-green-900/40 transition-colors group"
        >
          <BarChart3 className="w-5 h-5 text-green-400 group-hover:scale-110 transition-transform" />
          <div className="text-left">
            <p className="font-medium text-green-400">Executive Report</p>
            <p className="text-sm text-gray-300">Excel-ready comprehensive data</p>
          </div>
        </button>

        {/* Full Data Export */}
        <button
          onClick={() => generateEnhancedCSV(data, `full_data_export_${formatDate(new Date())}`)}
          className="flex items-center gap-3 p-4 bg-blue-900/30 border border-blue-600/50 rounded-lg hover:bg-blue-900/40 transition-colors group"
        >
          <Download className="w-5 h-5 text-blue-400 group-hover:scale-110 transition-transform" />
          <div className="text-left">
            <p className="font-medium text-blue-400">Full Dataset</p>
            <p className="text-sm text-gray-300">Complete extraction history (CSV)</p>
          </div>
        </button>
      </div>

      {/* Automated Reports Section */}
      <div className="border-t border-gray-600 pt-6 mb-6">
        <h4 className="font-semibold text-white mb-4 flex items-center gap-2">
          <Calendar className="w-5 h-5 text-orange-400" />
          Automated Reports
        </h4>

        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-3">
          <button
            onClick={generateWeeklyReport}
            className="flex items-center gap-2 p-3 bg-gray-700 border border-gray-600 rounded-lg hover:bg-gray-600 transition-colors text-sm"
          >
            <Calendar className="w-4 h-4 text-green-400" />
            <div className="text-left">
              <p className="font-medium text-white">Weekly</p>
              <p className="text-xs text-gray-300">Last 7 days</p>
            </div>
          </button>

          <button
            onClick={generateMonthlyReport}
            className="flex items-center gap-2 p-3 bg-gray-700 border border-gray-600 rounded-lg hover:bg-gray-600 transition-colors text-sm"
          >
            <Calendar className="w-4 h-4 text-yellow-400" />
            <div className="text-left">
              <p className="font-medium text-white">Monthly</p>
              <p className="text-xs text-gray-300">Last 30 days</p>
            </div>
          </button>

          <button
            onClick={generateCustomRangeAnalysis}
            className="flex items-center gap-2 p-3 bg-gray-700 border border-gray-600 rounded-lg hover:bg-gray-600 transition-colors text-sm"
          >
            <BarChart3 className="w-4 h-4 text-orange-400" />
            <div className="text-left">
              <p className="font-medium text-white">Custom Range</p>
              <p className="text-xs text-gray-300">Filtered period</p>
            </div>
          </button>

          <button
            onClick={() => {
              const seasonalContent = seasonalData.map(season => [
                season.season,
                season.totalDays || 0,
                season.totalTrips || 0,
                ((season.totalVolume || 0) / 1000000).toFixed(2),
                (season.avgTripsPerDay || 0).toFixed(1),
                season.highTripDays || 0,
                season.totalDays > 0 ? ((season.highTripDays || 0) / season.totalDays * 100).toFixed(1) : '0'
              ]);

              const headers = ['Season', 'Days', 'Trips', 'Volume (ML)', 'Avg/Day', 'Violations', 'Rate %'];
              const csvContent = [headers, ...seasonalContent]
                .map(row => row.map(cell => `"${cell}"`).join(','))
                .join('\n');

              downloadFile(csvContent, `seasonal_breakdown_${formatDate(new Date())}.csv`, 'text/csv');
            }}
            className="flex items-center gap-2 p-3 bg-gray-700 border border-gray-600 rounded-lg hover:bg-gray-600 transition-colors text-sm"
          >
            <BarChart3 className="w-4 h-4 text-purple-400" />
            <div className="text-left">
              <p className="font-medium text-white">Seasonal</p>
              <p className="text-xs text-gray-300">Season breakdown</p>
            </div>
          </button>
        </div>
      </div>

      {/* Export Information */}
      <div className="bg-gray-700 rounded-lg p-4">
        <p className="text-sm text-gray-300 mb-3">
          <strong className="text-white">Export Capabilities:</strong>
        </p>
        <div className="grid grid-cols-1 md:grid-cols-2 gap-4 text-xs text-gray-400">
          <ul className="space-y-1">
            <li>• PDF reports with professional formatting</li>
            <li>• Excel-ready CSV with executive summary</li>
            <li>• Enhanced data exports with risk analysis</li>
            <li>• Automated scheduling for regular reports</li>
          </ul>
          <ul className="space-y-1">
            <li>• Custom date range analysis</li>
            <li>• Seasonal breakdown reporting</li>
            <li>• Compliance status tracking</li>
            <li>• Real-time utilization calculations</li>
          </ul>
        </div>
      </div>
    </div>
  );
}