import { Download, FileText, Calendar, BarChart3 } from 'lucide-react';
import { WaterExtractionData } from '../utils/dataProcessing';
import { format } from 'date-fns';

interface ExportReportingProps {
  data: WaterExtractionData[];
  filteredData: WaterExtractionData[];
  seasonalData: any[];
  statsData: any;
  className?: string;
}

export function ExportReporting({
  data,
  filteredData,
  seasonalData,
  statsData,
  className = ''
}: ExportReportingProps) {

  // Native browser download function to replace file-saver
  const downloadFile = (content: string, filename: string, type: string = 'text/plain') => {
    const blob = new Blob([content], { type: `${type};charset=utf-8` });
    const url = URL.createObjectURL(blob);
    const link = document.createElement('a');
    link.href = url;
    link.download = filename;
    document.body.appendChild(link);
    link.click();
    document.body.removeChild(link);
    URL.revokeObjectURL(url);
  };

  const generateCSVReport = (dataToExport: WaterExtractionData[], filename: string) => {
    const headers = [
      'Date',
      'Trips',
      'Daily Limit (kL)',
      'Permitted Volume (kL)',
      'Actual Volume (kL)',
      'Cumulative Total (kL)',
      'Season',
      'Compliance Status'
    ];

    const csvData = dataToExport.map(row => [
      row.date,
      row.trips.toString(),
      row.dailyLimit.toString(),
      row.permittedVolume.toString(),
      row.actualVolume.toString(),
      row.cumulativeTotal.toString(),
      row.season,
      row.trips > 3 ? 'Violation' : 'Compliant'
    ]);

    const csvContent = [headers, ...csvData]
      .map(row => row.join(','))
      .join('\n');

    downloadFile(csvContent, `${filename}.csv`, 'text/csv');
  };

  const generateSeasonalReport = () => {
    const headers = [
      'Season',
      'Total Days',
      'Total Trips',
      'Total Volume (kL)',
      'Avg Trips/Day',
      'Avg Volume/Day (kL)',
      'High Trip Days',
      'Violation Rate (%)',
      'Risk Level'
    ];

    const csvData = seasonalData.map(season => [
      season.season,
      season.totalDays?.toString() || '0',
      season.totalTrips?.toString() || '0',
      (season.totalVolume || 0).toString(),
      (season.avgTripsPerDay || 0).toFixed(2),
      (season.avgVolumePerDay || 0).toFixed(0),
      (season.highTripDays || 0).toString(),
      season.totalDays > 0 ? ((season.highTripDays || 0) / season.totalDays * 100).toFixed(1) : '0',
      (season.highTripDays || 0) > season.totalDays * 0.1 ? 'High' : 'Low'
    ]);

    const csvContent = [headers, ...csvData]
      .map(row => row.join(','))
      .join('\n');

    const filename = `seasonal_analysis_${format(new Date(), 'yyyy-MM-dd')}`;
    downloadFile(csvContent, `${filename}.csv`, 'text/csv');
  };

  const generateDetailedReport = () => {
    const utilizationRate = (statsData.totalActualVolume / statsData.totalPermittedVolume) * 100;
    let riskLevel = 'Low';

    if (utilizationRate >= 100) riskLevel = 'Critical';
    else if (utilizationRate >= 90) riskLevel = 'High';
    else if (utilizationRate >= 75) riskLevel = 'Medium';

    const violationDays = statsData.highTripDays;
    const violationRate = (violationDays / statsData.totalDays * 100).toFixed(1);
    const remainingVolume = statsData.totalPermittedVolume - statsData.totalActualVolume;
    const avgDaily = statsData.totalActualVolume / statsData.totalDays;
    const daysRemaining = Math.floor(remainingVolume / avgDaily);

    const reportContent = `WATER EXTRACTION ANALYTICS REPORT
Generated on: ${format(new Date(), 'PPP')}
========================================================================

EXECUTIVE SUMMARY
========================================================================
Analysis Period: ${data[0]?.date || 'N/A'} to ${data[data.length - 1]?.date || 'N/A'}
Total Extraction Days: ${statsData.totalDays}
Total Trips: ${statsData.totalTrips.toLocaleString()}
Total Volume Extracted: ${(statsData.totalActualVolume / 1000000).toFixed(1)}M kL
Current Utilization: ${utilizationRate.toFixed(1)}%
Compliance Rate: ${(100 - parseFloat(violationRate)).toFixed(1)}%
Peak Activity Season: ${statsData.peakSeason}

RISK ASSESSMENT
========================================================================
Current Risk Level: ${riskLevel}
Days Exceeding 3 Trips: ${violationDays} (${violationRate}%)
Estimated Days Until Limit: ${daysRemaining > 0 ? daysRemaining : 'Limit Exceeded'}

SEASONAL ANALYSIS
========================================================================
${seasonalData.map(season => {
  const seasonViolationRate = season.totalDays > 0
    ? ((season.highTripDays || 0) / season.totalDays * 100).toFixed(1)
    : '0.0';
  return `${season.season}: ${season.totalTrips || 0} trips, ${((season.totalVolume || 0) / 1000000).toFixed(1)}M kL, ${seasonViolationRate}% violations`;
}).join('\n')}

RECOMMENDATIONS
========================================================================
${utilizationRate >= 95 ? '• URGENT: Reduce extraction immediately to avoid permit violation\n' : ''}${violationDays > statsData.totalDays * 0.1 ? '• Review operational procedures to maintain daily trip limits\n' : ''}${utilizationRate >= 80 ? '• Consider alternative water sources for peak demand periods\n' : ''}• Continue monitoring daily extraction rates closely
• Implement early warning system for approaching limits

========================================================================
Report generated by Water Extraction Analytics
`;

    const filename = `detailed_report_${format(new Date(), 'yyyy-MM-dd')}.txt`;
    downloadFile(reportContent, filename, 'text/plain');
  };

  const generateWeeklyReport = () => {
    const lastWeek = filteredData.slice(-7);
    const weeklyFilename = `weekly_report_${format(new Date(), 'yyyy-MM-dd')}`;
    generateCSVReport(lastWeek, weeklyFilename);
  };

  const generateMonthlyReport = () => {
    const lastMonth = filteredData.slice(-30);
    const monthlyFilename = `monthly_report_${format(new Date(), 'yyyy-MM-dd')}`;
    generateCSVReport(lastMonth, monthlyFilename);
  };

  const generateCustomRangeReport = () => {
    const customFilename = `custom_range_report_${format(new Date(), 'yyyy-MM-dd')}`;
    generateCSVReport(filteredData, customFilename);
  };

  return (
    <div className={`bg-gray-800 p-6 rounded-lg shadow-lg border border-gray-700 ${className}`}>
      <div className="flex items-center gap-3 mb-6">
        <FileText className="w-6 h-6 text-green-400" />
        <h3 className="text-xl font-semibold text-white">Export & Reporting</h3>
      </div>

      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4 mb-6">
        {/* Detailed Report */}
        <button
          onClick={generateDetailedReport}
          className="flex items-center gap-3 p-4 bg-red-900/30 border border-red-600/50 rounded-lg hover:bg-red-900/40 transition-colors"
        >
          <FileText className="w-5 h-5 text-red-400" />
          <div className="text-left">
            <p className="font-medium text-red-400">Detailed Report</p>
            <p className="text-sm text-gray-300">Complete analytics report (.txt)</p>
          </div>
        </button>

        {/* Full Data Export */}
        <button
          onClick={() => generateCSVReport(data, `full_data_export_${format(new Date(), 'yyyy-MM-dd')}`)}
          className="flex items-center gap-3 p-4 bg-blue-900/30 border border-blue-600/50 rounded-lg hover:bg-blue-900/40 transition-colors"
        >
          <Download className="w-5 h-5 text-blue-400" />
          <div className="text-left">
            <p className="font-medium text-blue-400">Full Data Export</p>
            <p className="text-sm text-gray-300">All extraction data (CSV)</p>
          </div>
        </button>

        {/* Seasonal Analysis */}
        <button
          onClick={generateSeasonalReport}
          className="flex items-center gap-3 p-4 bg-purple-900/30 border border-purple-600/50 rounded-lg hover:bg-purple-900/40 transition-colors"
        >
          <BarChart3 className="w-5 h-5 text-purple-400" />
          <div className="text-left">
            <p className="font-medium text-purple-400">Seasonal Analysis</p>
            <p className="text-sm text-gray-300">Season breakdown (CSV)</p>
          </div>
        </button>
      </div>

      {/* Automated Reports */}
      <div className="border-t border-gray-600 pt-6">
        <h4 className="font-semibold text-white mb-4 flex items-center gap-2">
          <Calendar className="w-5 h-5 text-green-400" />
          Quick Reports
        </h4>

        <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
          <button
            onClick={generateWeeklyReport}
            className="flex items-center gap-3 p-3 bg-gray-700 border border-gray-600 rounded-lg hover:bg-gray-600 transition-colors"
          >
            <Calendar className="w-4 h-4 text-green-400" />
            <div className="text-left">
              <p className="font-medium text-white text-sm">Weekly Report</p>
              <p className="text-xs text-gray-300">Last 7 days</p>
            </div>
          </button>

          <button
            onClick={generateMonthlyReport}
            className="flex items-center gap-3 p-3 bg-gray-700 border border-gray-600 rounded-lg hover:bg-gray-600 transition-colors"
          >
            <Calendar className="w-4 h-4 text-yellow-400" />
            <div className="text-left">
              <p className="font-medium text-white text-sm">Monthly Report</p>
              <p className="text-xs text-gray-300">Last 30 days</p>
            </div>
          </button>

          <button
            onClick={generateCustomRangeReport}
            className="flex items-center gap-3 p-3 bg-gray-700 border border-gray-600 rounded-lg hover:bg-gray-600 transition-colors"
          >
            <BarChart3 className="w-4 h-4 text-orange-400" />
            <div className="text-left">
              <p className="font-medium text-white text-sm">Custom Range</p>
              <p className="text-xs text-gray-300">Filtered data</p>
            </div>
          </button>
        </div>
      </div>

      {/* Export Info */}
      <div className="bg-gray-700 rounded-lg p-4 mt-6">
        <p className="text-sm text-gray-300 mb-2">
          <strong className="text-white">Export Information:</strong>
        </p>
        <ul className="text-xs text-gray-400 space-y-1">
          <li>• Detailed reports include risk analysis and recommendations</li>
          <li>• CSV exports contain detailed daily extraction data</li>
          <li>• All exports include compliance status for each day</li>
          <li>• Reports are generated with current filter settings</li>
        </ul>
      </div>
    </div>
  );
}