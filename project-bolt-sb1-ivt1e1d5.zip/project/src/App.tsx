import { useState, useEffect, useMemo } from 'react';
import { Droplets, Calendar } from 'lucide-react';
import {
  parseCSVData,
  aggregateByTimeframe,
  aggregateBySeason,
  filterData,
  WaterExtractionData
} from './utils/dataProcessing';
import {
  ActualVolumeChart,
  CumulativeComparisonChart,
  SeasonalBarChart,
  TripsOverTimeChart
} from './components/Charts';
import FilterControls from './components/FilterControls';
import StatsCards from './components/StatsCards';
import { AdvancedExportReporting } from './components/AdvancedExportReporting';

function App() {
  const [rawData, setRawData] = useState<WaterExtractionData[]>([]);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState<string | null>(null);

  const [filters, setFilters] = useState({
    startDate: '',
    endDate: '',
    minTrips: 0,
    maxTrips: 10,
    highlightThreshold: 3,
    timeframe: 'daily' as 'daily' | 'weekly' | 'monthly'
  });

  useEffect(() => {
    const loadData = async () => {
      try {
        const response = await fetch('/water_tanks_clean.csv');
        const csvText = await response.text();
        const data = parseCSVData(csvText);

        if (data.length > 0) {
          setRawData(data);
          setFilters(prev => ({
            ...prev,
            startDate: data[0].date,
            endDate: data[data.length - 1].date
          }));
        }
        setLoading(false);
      } catch (err) {
        setError('Failed to load water extraction data');
        setLoading(false);
      }
    };

    loadData();
  }, []);

  const dataRange = useMemo(() => {
    if (rawData.length === 0) {
      return { minDate: '', maxDate: '', minTrips: 0, maxTrips: 10 };
    }

    const trips = rawData.map(d => d.trips);
    return {
      minDate: rawData[0].date,
      maxDate: rawData[rawData.length - 1].date,
      minTrips: Math.min(...trips),
      maxTrips: Math.max(...trips)
    };
  }, [rawData]);

  const filteredData = useMemo(() => {
    return filterData(rawData, filters);
  }, [rawData, filters]);

  const aggregatedData = useMemo(() => {
    return aggregateByTimeframe(filteredData, filters.timeframe);
  }, [filteredData, filters.timeframe]);

  const seasonalData = useMemo(() => {
    return aggregateBySeason(filteredData, filters.highlightThreshold);
  }, [filteredData, filters.highlightThreshold]);

  const statsData = useMemo(() => {
    if (filteredData.length === 0) {
      return {
        totalDays: 0,
        totalTrips: 0,
        totalActualVolume: 0,
        totalPermittedVolume: 0,
        avgTripsPerDay: 0,
        highTripDays: 0,
        peakSeason: 'N/A',
        complianceRate: 0
      };
    }

    const totalTrips = filteredData.reduce((sum, d) => sum + d.trips, 0);
    const totalActualVolume = filteredData.reduce((sum, d) => sum + d.actualVolume, 0);
    const lastEntry = filteredData[filteredData.length - 1];
    const totalPermittedVolume = lastEntry.permittedVolume;
    const highTripDays = filteredData.filter(d => d.trips >= filters.highlightThreshold).length;

    const seasonTotals = seasonalData.reduce((prev, current) =>
      prev.totalActualVolume > current.totalActualVolume ? prev : current
    );

    return {
      totalDays: filteredData.length,
      totalTrips,
      totalActualVolume,
      totalPermittedVolume,
      avgTripsPerDay: totalTrips / filteredData.length,
      highTripDays,
      peakSeason: seasonTotals.season,
      complianceRate: (totalActualVolume / totalPermittedVolume) * 100
    };
  }, [filteredData, filters.highlightThreshold, seasonalData]);

  if (loading) {
    return (
      <div className="min-h-screen bg-gray-900 flex items-center justify-center">
        <div className="text-center">
          <Droplets className="w-12 h-12 text-blue-400 animate-pulse mx-auto mb-4" />
          <p className="text-white text-lg">Loading water extraction data...</p>
        </div>
      </div>
    );
  }

  if (error) {
    return (
      <div className="min-h-screen bg-gray-900 flex items-center justify-center">
        <div className="text-center">
          <div className="text-red-400 text-6xl mb-4">⚠️</div>
          <p className="text-white text-lg">{error}</p>
        </div>
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-gray-900">
      {/* Header */}
      <header className="bg-gray-800 border-b border-gray-700 px-6 py-4">
        <div className="flex items-center gap-3">
          <Droplets className="w-8 h-8 text-blue-400" />
          <div>
            <h1 className="text-2xl font-bold text-white">Water Extraction Analytics</h1>
            <p className="text-gray-400">Lot 701 Water Extraction Analysis</p>
          </div>
        </div>
      </header>

      <div className="container mx-auto px-6 py-8 space-y-8">
        {/* Filter Controls */}
        <FilterControls
          filters={filters}
          onFilterChange={setFilters}
          dataRange={dataRange}
        />

        {/* Stats Cards */}
        <StatsCards data={statsData} highlightThreshold={filters.highlightThreshold} />

        {/* Charts Grid */}
        <div className="grid grid-cols-1 xl:grid-cols-2 gap-8">
          {/* Actual Volume Chart */}
          <ActualVolumeChart data={aggregatedData} />

          {/* Trips Over Time */}
          <TripsOverTimeChart data={aggregatedData} />
        </div>

        {/* Cumulative Comparison Chart - Full Width */}
        <CumulativeComparisonChart data={aggregatedData} />

        {/* Seasonal Analysis */}
        <SeasonalBarChart data={seasonalData} />


        {/* Export & Reporting */}
        <AdvancedExportReporting
          data={rawData}
          filteredData={filteredData}
          seasonalData={seasonalData}
          statsData={statsData}
        />

        {/* Footer */}
        <footer className="text-center text-gray-500 py-8">
          <div className="flex items-center justify-center gap-2">
            <Calendar className="w-4 h-4" />
            <span>Analytics based on data provided by Di Owen (preliminary analytics may contain errors)</span>
          </div>
          <p className="text-sm mt-2">
            Data Period: {dataRange.minDate} to {dataRange.maxDate} |
            Total Records: {rawData.length} |
            Filtered Records: {filteredData.length}
          </p>
        </footer>
      </div>
    </div>
  );
}

export default App;
