export interface WaterExtractionData {
  date: string;
  trips: number;
  dailyLimit: number;
  permittedVolume: number;
  actualVolume: number;
  cumulativeTotal: number;
  season: string;
  year: number;
  month: number;
  day: number;
}

export const australianSeasons = {
  Summer: [12, 1, 2],
  Autumn: [3, 4, 5],
  Winter: [6, 7, 8],
  Spring: [9, 10, 11]
};

export function getAustralianSeason(month: number): string {
  for (const [season, months] of Object.entries(australianSeasons)) {
    if (months.includes(month)) {
      return season;
    }
  }
  return 'Unknown';
}

export function parseCSVData(csvText: string): WaterExtractionData[] {
  const lines = csvText.trim().split('\n');
  const data: WaterExtractionData[] = [];

  for (let i = 1; i < lines.length; i++) {
    const line = lines[i].trim();
    if (!line) continue;

    const [dateStr, tripsStr, dailyLimitStr, permittedVolumeStr, actualVolumeStr, cumulativeTotalStr] = line.split(',');

    if (!dateStr || dateStr === '2026-03-26') continue;

    const date = new Date(dateStr);
    const trips = parseFloat(tripsStr) || 0;
    const dailyLimit = parseFloat(dailyLimitStr) || 0;
    const permittedVolume = parseFloat(permittedVolumeStr) || 0;
    const actualVolume = parseFloat(actualVolumeStr) || 0;
    const cumulativeTotal = parseFloat(cumulativeTotalStr) || 0;

    data.push({
      date: dateStr,
      trips,
      dailyLimit,
      permittedVolume,
      actualVolume,
      cumulativeTotal,
      season: getAustralianSeason(date.getMonth() + 1),
      year: date.getFullYear(),
      month: date.getMonth() + 1,
      day: date.getDate()
    });
  }

  return data.sort((a, b) => new Date(a.date).getTime() - new Date(b.date).getTime());
}

export function aggregateByTimeframe(data: WaterExtractionData[], timeframe: 'daily' | 'weekly' | 'monthly'): WaterExtractionData[] {
  if (timeframe === 'daily') return data;

  const grouped = new Map<string, WaterExtractionData[]>();

  data.forEach(item => {
    const date = new Date(item.date);
    let key: string;

    if (timeframe === 'weekly') {
      const weekStart = new Date(date);
      weekStart.setDate(date.getDate() - date.getDay());
      key = weekStart.toISOString().split('T')[0];
    } else {
      key = `${date.getFullYear()}-${String(date.getMonth() + 1).padStart(2, '0')}`;
    }

    if (!grouped.has(key)) {
      grouped.set(key, []);
    }
    grouped.get(key)!.push(item);
  });

  return Array.from(grouped.entries()).map(([key, items]) => {
    const totalTrips = items.reduce((sum, item) => sum + item.trips, 0);
    const totalActualVolume = items.reduce((sum, item) => sum + item.actualVolume, 0);
    const avgDailyLimit = items.reduce((sum, item) => sum + item.dailyLimit, 0) / items.length;
    const lastItem = items[items.length - 1];

    return {
      date: key,
      trips: totalTrips,
      dailyLimit: avgDailyLimit,
      permittedVolume: lastItem.permittedVolume,
      actualVolume: totalActualVolume,
      cumulativeTotal: lastItem.cumulativeTotal,
      season: items[0].season,
      year: items[0].year,
      month: items[0].month,
      day: items[0].day
    };
  }).sort((a, b) => new Date(a.date).getTime() - new Date(b.date).getTime());
}

export function aggregateBySeason(data: WaterExtractionData[], tripThreshold: number = 3) {
  const seasonData = new Map<string, {
    totalTrips: number;
    totalActualVolume: number;
    totalVolume: number;
    totalDays: number;
    highTripDays: number;
    volumeExcessDays: number;
    avgTripsPerDay: number;
    avgVolumePerDay: number;
  }>();

  data.forEach(item => {
    if (!seasonData.has(item.season)) {
      seasonData.set(item.season, {
        totalTrips: 0,
        totalActualVolume: 0,
        totalVolume: 0,
        totalDays: 0,
        highTripDays: 0,
        volumeExcessDays: 0,
        avgTripsPerDay: 0,
        avgVolumePerDay: 0
      });
    }

    const seasonStats = seasonData.get(item.season)!;
    seasonStats.totalTrips += item.trips;
    seasonStats.totalActualVolume += item.actualVolume;
    seasonStats.totalVolume += item.actualVolume;
    seasonStats.totalDays += 1;

    // Count days with high trips (>3 trips per day)
    if (item.trips > tripThreshold) {
      seasonStats.highTripDays += 1;
    }

    // Count days where cumulative exceeds permitted (volume limit exceeded)
    if (item.cumulativeTotal > item.permittedVolume) {
      seasonStats.volumeExcessDays += 1;
    }
  });

  return Array.from(seasonData.entries()).map(([season, stats]) => ({
    season,
    ...stats,
    avgTripsPerDay: stats.totalTrips / stats.totalDays,
    avgVolumePerDay: stats.totalActualVolume / stats.totalDays
  }));
}

export function filterData(
  data: WaterExtractionData[],
  filters: {
    startDate?: string;
    endDate?: string;
    minTrips?: number;
    maxTrips?: number;
    highlightThreshold?: number;
  }
): WaterExtractionData[] {
  return data.filter(item => {
    const itemDate = new Date(item.date);

    if (filters.startDate && itemDate < new Date(filters.startDate)) return false;
    if (filters.endDate && itemDate > new Date(filters.endDate)) return false;
    if (filters.minTrips !== undefined && item.trips < filters.minTrips) return false;
    if (filters.maxTrips !== undefined && item.trips > filters.maxTrips) return false;

    return true;
  });
}